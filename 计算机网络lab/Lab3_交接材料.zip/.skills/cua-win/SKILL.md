---
name: cua-win
description: Drive the Windows desktop safely from an agent — screenshot, window focus, click, key, IME-proof text entry, OCR — plus evidence-grade screenshots for lab reports and DOCX/PDF render verification. Use when a task needs GUI automation, real screenshots as lab-report evidence, or when a generated Word/PDF document must be checked for layout and font problems.
---

# cua-win — Windows GUI automation + lab-report evidence pipeline

This skill packages what was learned building the Lab2 (Ethernet) report: the
parts that worked, and — more valuably — the traps that wasted hours.

## Golden rules

1. **Call `cua.py init` before anything else.** Without DPI awareness the
   process sees LOGICAL pixels while screenshots are PHYSICAL. On this host that
   is 1440×900 vs **2880×1800 (200 % scaling)** — every click would land at half
   the intended position. `cua.py` sets `PER_MONITOR_AWARE_V2` at import.
2. **Never type into an app if a non-keystroke path exists.** See the IME trap
   below. Prefer: CLI / config file / command-line argument ≫ clipboard paste ≫
   keystrokes.
3. **Focus, then verify, then act.** `SetForegroundWindow` alone is routinely
   refused by the Windows foreground lock. `cua.py focus` uses
   `AttachThreadInput` and reports whether it really succeeded. If
   `foreground != hwnd`, **stop** — your keystrokes are going somewhere else.
4. **One step, then re-observe.** Screenshot → decide one action → act →
   screenshot. Never queue a chain of clicks. Screen state changes underneath
   you (other windows steal focus; the user may be working).
5. **"The call returned ok" is not evidence.** Verify against independent
   state: UIA text value, a re-read file, `tshark` field extraction, or OCR.
   Measured failure: `SendInput` reported success while **nothing** reached the
   editor.
6. **Don't fabricate evidence.** If you cannot capture a state (dialog empty,
   tree won't expand), say so in the report and label any hand-drawn diagram as
   a diagram. Never present a rendered figure as a screenshot.

## Known traps on this host (verified, not speculation)

| Trap | Symptom | Fix |
|---|---|---|
| **微信输入法 (WeType) eats keystrokes** | sent `M1ABC123` → editor received `MABC23` (digits swallowed); `SendInput KEYEVENTF_UNICODE` → nothing at all | Use `cua.py type --method clipboard` (default). Verified fix. |
| IME turns ASCII punctuation into Chinese | typing `::` produced `方法:` | Same — clipboard, or pass the value as a CLI argument |
| **`PrintWindow` returns blank/stale** | single-window screenshots of Wireshark/Electron windows are empty or show an old frame | Use full-screen grab (`cua.py shot`) then crop; `--hwnd` crops the grab, it does not call PrintWindow |
| DPI dual coordinate space | clicks land at half position | `cua.py init` always |
| `tshark ... -w file` killed → **no file** | capture "succeeded" but pcapng missing | Use `-a duration:N` (graceful stop) and never `Kill()` the process |
| Console codepage is GBK | JSON output dies with `UnicodeEncodeError` on `•` or CJK | `sys.stdout.reconfigure(encoding='utf-8')` — already done in the scripts |
| PowerShell mangles CJK in `-c` heredocs | `Package not found at ...\����.docx` | Put Python in a `.py` file instead of `-c`, or pass paths via an env var |
| **LibreOffice silently substitutes CJK fonts** | report text looks "粗粗细细" — mixed stroke weights | See DOCX section: use a family with a *real* bold face (Microsoft YaHei) and set fonts on **runs**, not styles |

## Commands

All commands print one JSON object. `python` below is the bundled interpreter
returned by `load_workspace_dependencies`.

```bash
# session start (do this first)
python scripts/cua.py init

# find and take control of a window
python scripts/cua.py windows --process wireshark
python scripts/cua.py find --title "Wireshark"
python scripts/cua.py focus --hwnd 1234567          # verify foreground in output

# evidence screenshot (full grab; --hwnd crops to that window)
python scripts/cua.py shot --out evidence/step1.png --max-width 1600
python scripts/cua.py shot --out evidence/win.png --hwnd 1234567

# text entry (clipboard = IME-proof)
python scripts/cua.py type --text "eth.dst == ff:ff:ff:ff:ff:ff" --hwnd 1234567
python scripts/cua.py key --keys "ctrl+shift+r" "alt+f4"

# read text off the screen
python scripts/cua.py ocr --image evidence/step1.png --lang zh

# click, and find out what was actually under the pointer
python scripts/cua.py click --x 1200 --y 800
```

`scripts/selftest_cua.py` proves the whole chain works on this machine
(launches Notepad, types via clipboard, verifies with UIA **and** OCR, closes
without saving). Run it after any change to the scripts.

## Using it from other agents

* **Any agent with a shell** can call `cua.py` directly — no MCP needed, no
  agent-specific API. This is the most portable form.
* **MCP-capable clients** (ZCode, OpenCode, Cursor, Claude Desktop) can register
  `scripts/mcp_server.py` as a stdio server. Tools exposed: `cua_init`,
  `cua_windows`, `cua_find`, `cua_focus`, `cua_screenshot`, `cua_type`,
  `cua_key`, `cua_click`, `cua_ocr`. Verify with `python mcp_server.py --selftest`.
* **DSH** currently ships **no MCP client**, so within DSH use the CLI form.
* A `SKILL.md`-style skill is *documentation*, not a binary: the scripts are the
  portable part. ZCode uses market plugins, DSH uses skill folders, Claude/Codex
  use their own layouts — only the scripts transfer unchanged.

## Lab-report evidence workflow (5 more labs)

Target: **8–12 meaningful screenshots**, comparable to a good reference report,
each one proving a specific claim.

```
read the manual → list every "Turn-in" item → plan 1 screenshot per claim
   → arrange the window (maximize; widen relevant columns; expand the field
     tree; set the display filter that makes the claim visible)
   → full-screen grab → crop to the app window → name it NN_what_it_proves.png
   → in the report: caption states WHAT IT PROVES, not just what it shows
```

Rules that came out of Lab2:

* **Never screenshot a loading/splash state.** Wait for the real content, then
  re-grab. `cua.py shot` reports the foreground window so you can assert it.
* **Get the filter/field tree visible in the same frame as the result.** A
  screenshot of a packet list without the filter bar proves much less.
* **Record what each shot proves** next to the figure number. If a step's result
  is ambiguous, do not assume success — re-observe.
* **Save every capture file** (`pcapng`, etc.) beside the report; screenshots go
  stale, the raw data does not. `tshark -r file -T fields -e ...` can regenerate
  any number you quote.

### Wireshark-specific playbook

**Typing into the display-filter bar DOES work — verified.** This is the fix for
the screenshot problem, because it means every filter state can be set through
the GUI and captured, without relying on `-Y` command-line arguments:

```bash
# 1. focus the window (verify foreground in the output)
python scripts/cua.py focus --hwnd <hwnd>
# 2. CLICK the filter field. Ctrl+/ does NOT reliably focus it - clicking does.
python scripts/cua.py click --x 600 --y 168
# 3. clear, then paste through the clipboard (keystrokes get eaten by the IME)
python scripts/cua.py key --keys "ctrl+a" "delete"
python scripts/cua.py type --text "eth.dst == ff:ff:ff:ff:ff:ff"   # clipboard is the default
# 4. apply, then VERIFY via the status bar (green = valid syntax)
python scripts/cua.py key --keys "enter"
python scripts/cua.py shot --out ev.png --crop "0,<h-70>,<w>,70"
python scripts/cua.py ocr --image ev.png --lang zh
#    expect: 分组：110   Displayed: 11 (100.0%)
```

Measured result on this host: filter bar accepted the text, turned green (valid),
applied on Enter, and the status bar read **110 total / 11 displayed** — matching
`tshark`'s independent count exactly. Cross-check the count against
`tshark -r f.pcapng -Y 'eth.dst == ff:ff:ff:ff:ff:ff'` rather than trusting the UI.

Launching with state pre-applied is still the cheapest route when you do not
need a screenshot of the act of filtering:

```bash
# NOTE: no spaces around the operator, or Wireshark exits immediately (code 1).
"C:\Program Files\Wireshark\Wireshark.exe" -Y eth.dst==ff:ff:ff:ff:ff:ff "file.pcapng"
```

* To make a **capture-filter** screenshot (labs usually want it), the filter text
  is BPF: `icmp` / `ether multicast`. Remember `ether multicast` is a **capture**
  filter — as a display filter use `eth.dst.ig == 1`.
* The filter bar y-coordinate depends on the toolbar layout; take one full-screen
  grab first and measure it (Wireshark 4.6.8 maximized on this host: filter bar
  ≈ y=168 at 200 % scaling).
* Expanding the protocol tree by clicking the expander or `Ctrl+Shift+R` was
  **not reliable** in testing. If the tree will not expand, extract the same
  fields with `tshark -V` / `-T fields` and render them, and label the figure as
  dissector output rather than a screenshot.
* Verify numbers by re-parsing the capture, never by reading them off an image:
  `tshark -r f.pcapng -Y 'llc' -T fields -e frame.number`.

## DOCX deliverable workflow

Build with `python-docx`, then **verify by rendering**, because
`python-docx` does not paginate and LibreOffice may substitute fonts.

Font rules that fixed "粗粗细细" (mixed stroke weight):

1. Use a CJK family with a **real bold face** — on this host **Microsoft YaHei**
   or DengXian. **SimSun/宋体 has no bold**, so any bold becomes synthesized and
   blotchy; LibreOffice then substitutes *other* families (MS-Gothic,
   MicrosoftJhengHeiUILight) for individual glyphs.
2. Set fonts on **runs**, not only on styles. Style-level East-Asian fonts got
   substituted for every heading even when the style was correct.
3. Scripts: `scripts/build_docx_helpers.py` (paragraph/table/figure/monospace
   helpers with the working font handling).

Verification loop (run all three — each catches a different failure):

```bash
python scripts/check_docx_fonts.py report.docx     # per-font glyph coverage
python scripts/check_pdf_fonts.py   report.pdf     # substituted faces in the PDF
python scripts/check_pdf_layout.py  report.pdf     # trailing-blank / gap report
```

Render with the **bundled LibreOffice kit** (see the office-docx skill) unless
the user asks for their own install:

```bash
node <kit>/cli.js convert --input report.docx --output out/report.pdf
node <kit>/cli.js render  --input out/report.pdf --output-dir out/pages --dpi 110
```

Acceptance criteria before delivering: **0 substituted faces**, figure numbers
sequential, no page more than ~250 px short at the bottom, and every caption
stating what the figure proves.

## Safety

* Ordinary, reversible actions (focus, screenshot, type into a scratch file) need
  no confirmation. Everything else does:
  **deleting files, changing system/network settings, uninstalling, editing the
  registry, submitting forms, uploading coursework, sending mail, logging into
  new accounts, payments, anything irreversible** — stop and ask first.
* Close test apps **without saving** (`alt+f4` then discard), and verify no
  document was modified. Never type into a window that might hold the user's
  unsaved work; open your own scratch file instead.
* Screenshots capture the whole desktop, including unrelated private windows.
  Crop to the target app before putting anything in a report.
