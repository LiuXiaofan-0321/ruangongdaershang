<#
.SYNOPSIS
  Install the cua-win skill into an agent's skill directory.

.DESCRIPTION
  Discovers candidate skill directories from the filesystem (no hard-coded
  assumptions about any one agent) and copies this skill folder into the one you
  choose. Nothing is written outside the target directory. Always preview with
  -DryRun first; the installer prints exactly what it will do.

.PARAMETER Target
  dsh | zcode | codex | claude | workspace | <path>
    workspace = keep it in this project (portable, travels with the folder)

.PARAMETER DryRun
  Print the plan and exit without copying.

.PARAMETER List
  Only list discovered candidate directories.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\install.ps1 -List
  powershell -ExecutionPolicy Bypass -File .\install.ps1 -Target dsh -DryRun
  powershell -ExecutionPolicy Bypass -File .\install.ps1 -Target workspace
#>
[CmdletBinding()]
param(
    [string]$Target,
    [switch]$DryRun,
    [switch]$List
)

$ErrorActionPreference = 'Stop'
$Source = $PSScriptRoot
$SkillName = Split-Path $Source -Leaf

if (-not (Test-Path (Join-Path $Source 'SKILL.md'))) {
    throw "install.ps1 must sit next to SKILL.md (looked in $Source)"
}

function Get-Candidates {
    $out = [ordered]@{}
    $dshSkills = 'C:\Users\18963\AppData\Local\Programs\DeepSeek Harness\resources\runtime\office-skills'
    if (Test-Path $dshSkills) {
        # DSH discovers skills inside its runtime; a sibling folder is the
        # natural place for a user-supplied skill.
        $out['dsh'] = Join-Path (Split-Path $dshSkills -Parent) 'skills'
    }
    $zcode = Join-Path $env:USERPROFILE '.zcode\cli\plugins\data'
    if (Test-Path $zcode) { $out['zcode'] = Join-Path $zcode "cua-win@local" }
    $codex = Join-Path $env:USERPROFILE '.codex\skills'
    if (Test-Path $codex) { $out['codex'] = $codex }
    $claude = Join-Path $env:USERPROFILE '.claude\skills'
    if (Test-Path (Join-Path $env:USERPROFILE '.claude')) { $out['claude'] = $claude }
    $out['workspace'] = Join-Path (Split-Path $Source -Parent) $SkillName
    return $out
}

$candidates = Get-Candidates

if ($List -or -not $Target) {
    Write-Host "Discovered skill directories:" -ForegroundColor Cyan
    foreach ($k in $candidates.Keys) {
        $exists = Test-Path $candidates[$k]
        $mark = if ($exists) { '[exists]' } else { '[create]' }
        Write-Host ("  {0,-10} {1,-9} {2}" -f $k, $mark, $candidates[$k])
    }
    if (-not $Target) {
        Write-Host "`nChoose one:  -Target <name>`nPreview first with -DryRun." -ForegroundColor Yellow
    }
    return
}

$dest = if ($candidates.Contains($Target)) { $candidates[$Target] } else { $Target }
$final = if ((Split-Path $dest -Leaf) -eq $SkillName) { $dest } else { Join-Path $dest $SkillName }

Write-Host "Source      : $Source"
Write-Host "Destination : $final"
Write-Host "Files       :"
$files = Get-ChildItem $Source -Recurse -File |
    Where-Object { $_.FullName -notmatch '\\__pycache__\\' -and $_.Extension -ne '.pyc' }
$files | ForEach-Object {
    Write-Host ("   {0,-28} {1,8:N1} KB" -f $_.Name, ($_.Length / 1KB))
}

if ($DryRun) {
    Write-Host "`nDRY RUN - nothing copied." -ForegroundColor Yellow
    return
}

if (Test-Path $final) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup = "$final.bak-$stamp"
    Write-Host "`nExisting install found; backing up to $backup" -ForegroundColor Yellow
    Copy-Item $final $backup -Recurse -Force
}

New-Item -ItemType Directory -Path $final -Force | Out-Null
$files | ForEach-Object {
    $rel = $_.FullName.Substring($Source.Length).TrimStart('\')
    $target = Join-Path $final $rel
    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item $_.FullName $target -Force
}
Write-Host "`nInstalled to $final" -ForegroundColor Green
Write-Host "Verify with:"
Write-Host "  python `"$final\scripts\selftest_cua.py`""
Write-Host "  python `"$final\scripts\selftest_docx.py`""
