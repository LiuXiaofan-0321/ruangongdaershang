# cua-win — Windows GUI automation + lab-report evidence toolkit

An agent-agnostic toolkit for driving the Windows desktop and turning the result
into a verified Word/PDF report. Built while producing the Lab2 (Ethernet)
实验报告, from what actually worked on this machine.

Read **[SKILL.md](SKILL.md)** first — it contains the workflow and the traps.

## What's here

```
SKILL.md                    workflow, golden rules, verified traps, Wireshark + DOCX playbooks
scripts/
  cua.py                    core primitives, JSON output: init/info/windows/find/focus/
                            shot/type/key/click/ocr
  selftest_cua.py           proves the GUI chain works (Notepad + UIA + OCR read-back)
  mcp_server.py             MCP stdio server wrapping cua.py (for ZCode / OpenCode / Cursor)
  clip.py                   get/set the clipboard (IME-proof text entry helper)
  diag_type.py              measures which text-injection method survives this host's IME
  build_docx_helpers.py     python-docx helpers with LibreOffice-safe font handling
  selftest_docx.py          builds a doc and runs all three checks end to end
  check_docx_fonts.py       per-font glyph coverage for a DOCX
  check_pdf_fonts.py        detects fonts the renderer substituted into a PDF
  check_pdf_layout.py       per-page trailing-blank / pagination report
install.ps1                 copy this skill into an agent's skill directory
```

## Quick start

```powershell
# bundled interpreter from load_workspace_dependencies
$py = "C:\Users\18963\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
$S  = "C:\University Courses\计算机网络lab\.skills\cua-win\scripts"

& $py "$S\cua.py" init          # ALWAYS first: sets DPI awareness
& $py "$S\selftest_cua.py"      # expect OVERALL: PASS
& $py "$S\selftest_docx.py"     # expect OVERALL: PASS
```

Optional but recommended for OCR:

```powershell
& $py -m pip install winsdk    # Windows built-in OCR (en-US + zh-Hans-CN on this host)
```

Optional, for UI Automation text read-back:

```powershell
& $py -m pip install comtypes
```

## Using it from other agents

* **Shell-capable agent (any)** — call `cua.py` / the check scripts directly. No
  MCP, no agent API. This is the portable form; the scripts are plain Windows
  Python (`ctypes` + PIL) and nothing here is DSH-specific.
* **MCP-capable client** (ZCode, OpenCode, Cursor, Claude Desktop) — register the
  stdio server:

  ```json
  {
    "mcpServers": {
      "cua-win": {
        "command": "C:\\Users\\18963\\.dsh\\dsh-runtimes\\dsh-primary-runtime\\dependencies\\python\\python.exe",
        "args": ["C:\\University Courses\\计算机网络lab\\.skills\\cua-win\\scripts\\mcp_server.py"]
      }
    }
  }
  ```

  Tools: `cua_init`, `cua_windows`, `cua_find`, `cua_focus`, `cua_screenshot`,
  `cua_type`, `cua_key`, `cua_click`, `cua_ocr`. Verify with
  `python mcp_server.py --selftest`.
* **DSH** — ships no MCP client, so use the CLI form there.
* A `SKILL.md` file is documentation, not an executable interface: ZCode uses
  market plugins, DSH uses skill folders, Claude/Codex use their own layouts.
  **Only the scripts transfer unchanged.**

## Install into an agent

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 -Target dsh
powershell -ExecutionPolicy Bypass -File .\install.ps1 -Target zcode -DryRun
powershell -ExecutionPolicy Bypass -File .\install.ps1 -List
```

Targets are discovered from the filesystem; nothing is written outside the
directory you choose, and `-DryRun` shows the plan first.

## Proven on this host

| Capability | Evidence |
|---|---|
| Screenshot at true resolution | `cua.py init` → 2880×1800 physical, DPI `per-monitor-v2` |
| Clipboard text entry | UIA read-back returned `CUA probe 74B 0x0800` exactly |
| OCR | Windows engine, `en-US` + `zh-Hans-CN`, read back the same probe |
| Wireshark filter via GUI | filter bar accepted `eth.dst == ff:ff:ff:ff:ff:ff`, turned green; status bar read **分组：110 / Displayed: 11**, matching `tshark` |
| DOCX pipeline | 0 substituted PDF fonts, no layout gaps, figure numbers sequential |
| MCP server | initialize + tools/list + real tool calls over stdio JSON-RPC |

## Known limits

* Keystroke injection is unreliable here: the 微信输入法 swallows digits
  (`M1ABC123` arrived as `MABC23`) and `SendInput(KEYEVENTF_UNICODE)` can be
  dropped entirely. **Always prefer the clipboard method.**
* `PrintWindow` returns blank/stale content for many windows; only the
  full-screen grab is trusted.
* PowerShell corrupts non-ASCII characters when passing them as arguments to a
  native program. Pass `--dir <folder>` and let the script resolve filenames
  itself, or write a `.py` file instead of using `python -c`.
* Wireshark's protocol-tree expansion was not reliable; fall back to `tshark -V`
  output and label such figures as dissector output.
