# -*- coding: utf-8 -*-
"""audit_figures.py - pair each figure caption with the image that precedes it.

Catches the failure mode where a caption is inserted but its image is not (or the
image is appended at the end of the document), which python-docx does not report.

Usage: python audit_figures.py --dir <folder> --match RE
"""
import argparse
import glob
import os
import re
import sys
import zipfile

import docx
from docx.text.paragraph import Paragraph

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BLIP = "{http://schemas.openxmlformats.org/drawingml/2006/main}blip"
NSREL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir")
    ap.add_argument("--match", default="")
    ap.add_argument("paths", nargs="*")
    args = ap.parse_args()

    paths = list(args.paths)
    if args.dir:
        for f in sorted(glob.glob(os.path.join(args.dir, "*.docx"))):
            if args.match and not re.search(args.match, os.path.basename(f), re.I):
                continue
            if not os.path.basename(f).startswith("~$"):
                paths.append(f)

    for path in paths:
        doc = docx.Document(path)
        rels = doc.part.rels
        print("=" * 76)
        print(os.path.basename(path))
        n_img = n_cap = 0
        problems = []
        pending = None      # (index, rId, resolved target or None)
        for i, el in enumerate(doc.element.body.iterchildren()):
            if el.tag.split("}")[-1] != "p":
                continue
            para = Paragraph(el, doc)
            blips = el.findall(f".//{BLIP}")
            if blips:
                n_img += 1
                embeds = [b.get(f"{NSREL}embed") for b in blips]
                resolved = []
                for rid in embeds:
                    try:
                        resolved.append(os.path.basename(rels[rid].target_ref))
                    except Exception:
                        resolved.append(f"<broken {rid}>")
                pending = (n_img, resolved)
                print(f"  img#{n_img:<3} -> {resolved}")
                continue
            if para.style.name == "Caption" and para.text.strip().startswith("图"):
                n_cap += 1
                cap_no = re.match(r"图\s*(\d+)", para.text.strip())
                if pending is None:
                    problems.append(f"caption {para.text.strip()[:40]!r} has NO preceding image")
                    print(f"  CAP  !! no image before: {para.text.strip()[:56]}")
                else:
                    pending = None
                continue
            if para.text.strip():
                pending = None
        print(f"  images in body: {n_img}   figure captions: {n_cap}")
        if n_img != n_cap:
            print(f"  !! MISMATCH: {n_cap} captions but {n_img} images")
        for p in problems:
            print(f"  !! {p}")


if __name__ == "__main__":
    main()
