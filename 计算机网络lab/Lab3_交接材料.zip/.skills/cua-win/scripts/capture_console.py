# -*- coding: utf-8 -*-
"""capture_console.py - run a command in a real console window and screenshot it.

Lab reports usually want the command AND its output visible. This opens a
console, runs the command, optionally waits, keeps the window open, grabs the
screen (crop to the window), and leaves the window for the caller to inspect or
close.

Usage:
  python capture_console.py --cmd "ping -4 -n 4 www.baidu.com" --out ev/ping.png \
      [--wait 12] [--cols 120] [--lines 40] [--keep]
"""
import argparse
import os
import subprocess
import sys
import tempfile
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
CUA = os.path.join(HERE, "cua.py")


def cua(*args):
    import json
    p = subprocess.run([sys.executable, CUA, *args], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    try:
        return json.loads(p.stdout.strip().splitlines()[-1])
    except Exception:
        return {"ok": False, "raw": p.stdout[-300:], "err": p.stderr[-300:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cmd", required=True, help="command to run in cmd.exe")
    ap.add_argument("--out", required=True)
    ap.add_argument("--title", default="命令与输出")
    ap.add_argument("--wait", type=float, default=12.0)
    ap.add_argument("--cols", type=int, default=120)
    ap.add_argument("--lines", type=int, default=40)
    ap.add_argument("--keep", action="store_true", help="do not close the console")
    args = ap.parse_args()

    # a wrapper .bat keeps the window open after the command finishes
    bat = os.path.join(tempfile.mkdtemp(prefix="cua-console-"), "run.bat")
    with open(bat, "w", encoding="gbk", errors="replace") as fh:
        fh.write("@echo off\r\n")
        fh.write(f"mode con: cols={args.cols} lines={args.lines}\r\n")
        fh.write(f"title {args.title}\r\n")
        fh.write("echo $ " + args.cmd + "\r\n")
        fh.write("echo.\r\n")
        fh.write(args.cmd + "\r\n")
        fh.write("echo.\r\n")
        fh.write("echo ---- press any key to close ----\r\n")

    proc = subprocess.Popen(["cmd.exe", "/c", "start", "", bat], shell=False)
    time.sleep(args.wait)

    win = cua("find", "--title", args.title)
    match = win.get("match")
    if not match:
        print(f'{{"ok": false, "error": "console window not found"}}')
        return 1
    shot = cua("shot", "--out", args.out, "--hwnd", str(match["hwnd"]),
               "--max-width", "2000")
    print(f'{{"ok": true, "out": "{shot.get("path", "")}", '
          f'"w": {shot.get("w")}, "h": {shot.get("h")}, '
          f'"hwnd": {match["hwnd"]}, "cmd": "{args.cmd}"}}')

    if not args.keep:
        cua("focus", "--hwnd", str(match["hwnd"]))
        cua("key", "--keys", "alt+f4")
        time.sleep(0.8)
    return 0


if __name__ == "__main__":
    sys.exit(main())
