#!/usr/bin/env python
"""cua.py - Computer-Use primitives for Windows agents. JSON-first CLI.

Every subcommand prints ONE JSON object to stdout, so any agent that can run a
process and parse JSON can use it. No agent-specific API, no MCP required.

Design rules learned the hard way (see SKILL.md):
  * Call init() first in every process: without DPI awareness this process sees
    LOGICAL pixels (e.g. 1440x900) while screenshots are PHYSICAL (2880x1800),
    so every click lands at half the intended position.
  * Screenshots use a full-screen grab, never PrintWindow: PrintWindow returns
    blank or stale content for Electron/Chromium windows and for some Qt trees.
  * Typing uses SendInput(KEYEVENTF_UNICODE): a Chinese IME or a non-English
    keyboard layout otherwise mangles ASCII punctuation.
  * Input is delivered to the FOREGROUND window. Always focus + verify first;
    SetForegroundWindow alone is often refused by the Windows foreground lock.

Usage:
  python cua.py init
  python cua.py info
  python cua.py windows [--title RE] [--process RE]
  python cua.py find --title RE
  python cua.py focus --hwnd N
  python cua.py shot [--out F] [--crop x,y,w,h] [--max-width N]
  python cua.py type --text S [--hwnd N]
  python cua.py key --keys ctrl+shift+r [--hwnd N]
  python cua.py click --x N --y N [--button left|right] [--double] [--hwnd N]
  python cua.py ocr --image F [--lang en|zh]
  python cua.py ping
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import sys
import time
from ctypes import wintypes

# Windows console default codepage is GBK on a zh-CN host; OCR text and window
# titles can contain characters it cannot encode, which would abort the JSON
# output mid-write. Force UTF-8 so stdout is always parseable.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# --------------------------------------------------------------------------
# DPI awareness must be set before any window/metric call.
# --------------------------------------------------------------------------
_DPI_MODE = "unset"


def init_dpi() -> str:
    global _DPI_MODE
    if _DPI_MODE != "unset":
        return _DPI_MODE
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)      # PER_MONITOR_AWARE_V2
        _DPI_MODE = "per-monitor-v2"
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
            _DPI_MODE = "system-aware"
        except Exception as exc:                             # noqa: BLE001
            _DPI_MODE = f"failed:{exc}"
    return _DPI_MODE


init_dpi()

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
kernel32 = ctypes.windll.kernel32

SW_RESTORE = 9
HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
SWP_NOMOVE, SWP_NOSIZE, SWP_SHOWWINDOW = 0x0002, 0x0001, 0x0040
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
ULONG_PTR = ctypes.c_uint64 if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_uint32


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_uint32), ("time", ctypes.c_uint32),
                ("dwExtraInfo", ULONG_PTR)]


class _INPUTunion(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("padding", ctypes.c_ubyte * 24)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.c_uint32), ("u", _INPUTunion)]


user32.GetWindowDC.restype = wintypes.HDC
user32.GetWindowDC.argtypes = [wintypes.HWND]
user32.GetDC.restype = wintypes.HDC
user32.GetDC.argtypes = [wintypes.HWND]
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
user32.WindowFromPoint.restype = wintypes.HWND
user32.WindowFromPoint.argtypes = [wintypes.POINT]
user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
gdi32.CreateCompatibleDC.restype = wintypes.HDC
gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
gdi32.CreateCompatibleBitmap.restype = wintypes.HBITMAP
gdi32.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
gdi32.SelectObject.restype = wintypes.HGDIOBJ
gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.DeleteDC.argtypes = [wintypes.HDC]


def out(**kw):
    print(json.dumps(kw, ensure_ascii=False, default=str))
    return 0


def window_title(hwnd) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    if n <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def window_class(hwnd) -> str:
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def window_rect(hwnd):
    r = RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    return (r.left, r.top, r.right - r.left, r.bottom - r.top)


def process_name(pid: int) -> str:
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return ""
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(size.value)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return os.path.basename(buf.value)
        return ""
    finally:
        kernel32.CloseHandle(h)


def list_windows():
    rows = []
    fg = user32.GetForegroundWindow()
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        title = window_title(hwnd)
        if not title:
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        rect = window_rect(hwnd)
        rows.append({
            "hwnd": int(hwnd),
            "title": title,
            "class": window_class(hwnd),
            "pid": int(pid.value),
            "process": process_name(pid.value),
            "rect": {"x": rect[0], "y": rect[1], "w": rect[2], "h": rect[3]} if rect else None,
            "minimized": bool(user32.IsIconic(hwnd)),
            "foreground": hwnd == fg,
        })
        return True

    user32.EnumWindows(EnumProc(cb), 0)
    return rows


# --------------------------------------------------------------------------
# screenshot (full-screen grab only; PrintWindow is deliberately not used)
# --------------------------------------------------------------------------
def grab(region=None):
    from PIL import ImageGrab
    img = ImageGrab.grab(all_screens=True)
    if region:
        x, y, w, h = region
        img = img.crop((x, y, x + w, y + h))
    return img


def save_img(img, path, max_width=None):
    if max_width and img.width > max_width:
        ratio = max_width / img.width
        img = img.resize((max_width, int(img.height * ratio)))
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    img.save(path)
    return {"path": path, "w": img.width, "h": img.height,
            "bytes": os.path.getsize(path)}


# --------------------------------------------------------------------------
# focus (AttachThreadInput is required; SetForegroundWindow alone is refused)
# --------------------------------------------------------------------------
def focus(hwnd) -> bool:
    if not user32.IsWindow(hwnd):
        return False
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, SW_RESTORE)
        time.sleep(0.3)
    fg = user32.GetForegroundWindow()
    fg_thread = user32.GetWindowThreadProcessId(fg, None)
    my_thread = kernel32.GetCurrentThreadId()
    attached = False
    if fg_thread and fg_thread != my_thread:
        attached = bool(user32.AttachThreadInput(my_thread, fg_thread, True))
    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
        user32.SetFocus(hwnd)
        time.sleep(0.15)
        if user32.GetForegroundWindow() != hwnd:
            user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                                SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
            user32.SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0,
                                SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
            user32.SetForegroundWindow(hwnd)
            time.sleep(0.2)
    finally:
        if attached:
            user32.AttachThreadInput(my_thread, fg_thread, False)
    return user32.GetForegroundWindow() == hwnd


# --------------------------------------------------------------------------
# typing / keys
# --------------------------------------------------------------------------
def _send_unicode(ch: str):
    code = ord(ch)
    for flags in (KEYEVENTF_UNICODE, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP):
        inp = INPUT(type=INPUT_KEYBOARD)
        inp.u.ki = KEYBDINPUT(0, code, flags, 0, 0)
        user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


VK = {"enter": 0x0D, "esc": 0x1B, "tab": 0x09, "space": 0x20, "backspace": 0x08,
      "delete": 0x2E, "home": 0x24, "end": 0x23, "left": 0x25, "up": 0x26,
      "right": 0x27, "down": 0x28, "pageup": 0x21, "pagedown": 0x22,
      "ctrl": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B,
      "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
      "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B}


def _vk_down(vk):
    user32.keybd_event(vk, 0, 0, 0)


def _vk_up(vk):
    user32.keybd_event(vk, 0, 2, 0)


def send_keys(combo: str):
    parts = [p.strip().lower() for p in combo.split("+")]
    vks = [VK.get(p, (ord(p.upper()) if len(p) == 1 else None)) for p in parts]
    if any(v is None for v in vks):
        raise ValueError(f"unknown key in {combo!r}")
    for v in vks:
        _vk_down(v)
    for v in reversed(vks):
        _vk_up(v)


def type_text(text: str, interval: float = 0.012):
    for ch in text:
        _send_unicode(ch)
        time.sleep(interval)


# --------------------------------------------------------------------------
# clipboard path - the ONLY reliable way to enter text on a machine with an
# aggressive IME. Measured on this host: the 微信输入法 (WeType) swallows digits
# out of injected keystrokes ("M1ABC123" arrived as "MABC23"), and
# KEYEVENTF_UNICODE is dropped entirely by some editors. Pasting bypasses the
# keyboard entirely.
# --------------------------------------------------------------------------
CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
kernel32.GlobalAlloc.restype = ctypes.c_void_p
kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
user32.OpenClipboard.argtypes = [wintypes.HWND]
user32.SetClipboardData.restype = wintypes.HANDLE
user32.SetClipboardData.argtypes = [ctypes.c_uint, wintypes.HANDLE]


def clipboard_set(text: str):
    if not user32.OpenClipboard(None):
        raise RuntimeError("OpenClipboard failed")
    try:
        user32.EmptyClipboard()
        data = text.encode("utf-16-le") + b"\x00\x00"
        h = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not h:
            raise RuntimeError("GlobalAlloc failed")
        ptr = kernel32.GlobalLock(h)
        ctypes.memmove(ptr, data, len(data))
        kernel32.GlobalUnlock(h)
        if not user32.SetClipboardData(CF_UNICODETEXT, h):
            raise RuntimeError("SetClipboardData failed")
    finally:
        user32.CloseClipboard()


def clipboard_get() -> str:
    if not user32.OpenClipboard(None):
        raise RuntimeError("OpenClipboard failed")
    try:
        h = user32.GetClipboardData(CF_UNICODETEXT)
        if not h:
            return ""
        ptr = kernel32.GlobalLock(ctypes.c_void_p(h))
        if not ptr:
            return ""
        try:
            return ctypes.wstring_at(ptr)
        finally:
            kernel32.GlobalUnlock(ctypes.c_void_p(h))
    finally:
        user32.CloseClipboard()


def type_via_clipboard(text: str, clear_existing: bool = False):
    """Paste text through the clipboard: strongest method, IME-independent."""
    prev = ""
    try:
        prev = clipboard_get()
    except Exception:
        pass
    clipboard_set(text)
    time.sleep(0.15)
    if clear_existing:
        send_keys("ctrl+a")
        time.sleep(0.12)
        send_keys("delete")
        time.sleep(0.12)
    send_keys("ctrl+v")
    time.sleep(0.35)
    return prev


def click(x, y, button="left", double=False):
    user32.SetCursorPos(int(x), int(y))
    time.sleep(0.12)
    if button == "right":
        down, up = 0x0008, 0x0010
    else:
        down, up = 0x0002, 0x0004
    for _ in range(2 if double else 1):
        user32.mouse_event(down, 0, 0, 0, 0)
        user32.mouse_event(up, 0, 0, 0, 0)
        time.sleep(0.08)


# --------------------------------------------------------------------------
# OCR via the Windows built-in engine (needs: pip install winsdk)
# --------------------------------------------------------------------------
def ocr_image(path, lang="en"):
    import asyncio
    import winsdk.windows.globalization as gl
    import winsdk.windows.graphics.imaging as imaging
    import winsdk.windows.media.ocr as ocr
    import winsdk.windows.storage as storage

    async def run():
        f = await storage.StorageFile.get_file_from_path_async(os.path.abspath(path))
        stream = await f.open_async(storage.FileAccessMode.READ)
        decoder = await imaging.BitmapDecoder.create_async(stream)
        bitmap = await decoder.get_software_bitmap_async()
        tags = ["zh-Hans-CN", "en-US"] if lang == "zh" else ["en-US"]
        engine = None
        used = None
        for tag in tags:
            language = gl.Language(tag)
            if ocr.OcrEngine.is_language_supported(language):
                engine = ocr.OcrEngine.try_create_from_language(language)
                if engine:
                    used = tag
                    break
        if engine is None:
            engine = ocr.OcrEngine.try_create_from_user_profile_languages()
        if engine is None:
            return None
        result = await engine.recognize_async(bitmap)
        lines = []
        for line in result.lines:
            ws = list(line.words)
            if not ws:
                continue
            x0 = min(w.bounding_rect.x for w in ws)
            y0 = min(w.bounding_rect.y for w in ws)
            lines.append({"text": line.text, "x": int(x0), "y": int(y0)})
        return used, lines

    return asyncio.run(run())


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------
def cmd_init(_a):
    from PIL import ImageGrab
    probe = ImageGrab.grab(all_screens=True)
    return out(ok=True, dpi_mode=_DPI_MODE, screen={"w": probe.width, "h": probe.height},
               python=sys.version.split()[0], platform=sys.platform)


def cmd_ping(_a):
    return out(ok=True, pong=True, dpi_mode=_DPI_MODE)


def cmd_info(_a):
    from PIL import ImageGrab
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    probe = ImageGrab.grab(all_screens=True)
    fg = user32.GetForegroundWindow()
    return out(ok=True, dpi_mode=_DPI_MODE,
               screen={"w": probe.width, "h": probe.height},
               cursor={"x": pt.x, "y": pt.y},
               foreground={"hwnd": int(fg), "title": window_title(fg)},
               windows_visible=len(list_windows()))


def cmd_windows(a):
    rows = list_windows()
    if a.title:
        rows = [r for r in rows if a.title.lower() in r["title"].lower()]
    if a.process:
        rows = [r for r in rows if a.process.lower() in r["process"].lower()]
    return out(ok=True, count=len(rows), windows=rows)


def cmd_find(a):
    rows = [r for r in list_windows() if a.title.lower() in r["title"].lower()]
    best = None
    for r in rows:
        if r["foreground"]:
            best = r
            break
    best = best or (rows[0] if rows else None)
    return out(ok=True, count=len(rows), match=best, all=rows)


def cmd_focus(a):
    hwnd = a.hwnd or (user32.GetForegroundWindow() if a.title else None)
    if a.title and not a.hwnd:
        m = [r for r in list_windows() if a.title.lower() in r["title"].lower()]
        hwnd = m[0]["hwnd"] if m else None
    if not hwnd:
        return out(ok=False, error="no window matched")
    ok = focus(hwnd)
    return out(ok=ok, hwnd=int(hwnd), foreground=int(user32.GetForegroundWindow()),
               title=window_title(hwnd))


def cmd_shot(a):
    crop = tuple(int(v) for v in a.crop.split(",")) if a.crop else None
    if a.hwnd:
        r = window_rect(a.hwnd)
        if r:
            crop = r
    img = grab(crop)
    path = a.out or os.path.join(os.environ.get("TEMP", "."),
                                 time.strftime("cua-%Y%m%d-%H%M%S.png"))
    info = save_img(img, path, a.max_width)
    fg = user32.GetForegroundWindow()
    return out(ok=True, **info, crop=crop,
               foreground={"hwnd": int(fg), "title": window_title(fg)})


def cmd_type(a):
    if a.hwnd and not focus(a.hwnd):
        return out(ok=False, error="could not focus target window before typing")
    before = window_title(user32.GetForegroundWindow())
    prev_clip = None
    if a.method == "clipboard":
        prev_clip = type_via_clipboard(a.text, a.clear)
    else:
        type_text(a.text, a.interval)
    time.sleep(0.2)
    return out(ok=True, method=a.method, typed=a.text, chars=len(a.text),
               clipboard_restored=bool(prev_clip) or a.method != "clipboard",
               foreground_title=before,
               warning=None if a.method == "clipboard" else
               "keystroke injection can be mangled by an IME; prefer --method clipboard")


def cmd_key(a):
    if a.hwnd and not focus(a.hwnd):
        return out(ok=False, error="could not focus target window before keys")
    for combo in a.keys:
        send_keys(combo)
        time.sleep(0.25)
    return out(ok=True, sent=a.keys,
               foreground_title=window_title(user32.GetForegroundWindow()))


def cmd_click(a):
    if a.hwnd and not focus(a.hwnd):
        return out(ok=False, error="could not focus target window before click")
    target = user32.WindowFromPoint(wintypes.POINT(a.x, a.y))
    click(a.x, a.y, a.button, a.double)
    return out(ok=True, clicked={"x": a.x, "y": a.y, "button": a.button, "double": a.double},
               window_at_point={"hwnd": int(target), "title": window_title(target),
                                "class": window_class(target)})


def cmd_ocr(a):
    res = ocr_image(a.image, a.lang)
    if res is None:
        return out(ok=False, error="no OCR engine available (pip install winsdk)")
    used, lines = res
    return out(ok=True, engine_language=used, count=len(lines), lines=lines)


def build_parser():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init").set_defaults(func=cmd_init)
    sub.add_parser("ping").set_defaults(func=cmd_ping)
    sub.add_parser("info").set_defaults(func=cmd_info)

    w = sub.add_parser("windows")
    w.add_argument("--title")
    w.add_argument("--process")
    w.set_defaults(func=cmd_windows)

    f = sub.add_parser("find")
    f.add_argument("--title", required=True)
    f.set_defaults(func=cmd_find)

    fo = sub.add_parser("focus")
    fo.add_argument("--hwnd", type=int)
    fo.add_argument("--title")
    fo.set_defaults(func=cmd_focus)

    s = sub.add_parser("shot")
    s.add_argument("--out")
    s.add_argument("--crop", help="x,y,w,h")
    s.add_argument("--hwnd", type=int, help="crop to this window's rect")
    s.add_argument("--max-width", type=int, default=1600,
                   help="downscale before saving (keeps files small)")
    s.set_defaults(func=cmd_shot)

    t = sub.add_parser("type")
    t.add_argument("--text", required=True)
    t.add_argument("--hwnd", type=int)
    t.add_argument("--interval", type=float, default=0.012)
    t.add_argument("--method", default="clipboard", choices=["clipboard", "keys"],
                   help="clipboard (default, IME-proof) or keys (SendInput Unicode)")
    t.add_argument("--clear", action="store_true",
                   help="select-all + delete before pasting")
    t.set_defaults(func=cmd_type)

    k = sub.add_parser("key")
    k.add_argument("--keys", nargs="+", required=True)
    k.add_argument("--hwnd", type=int)
    k.set_defaults(func=cmd_key)

    c = sub.add_parser("click")
    c.add_argument("--x", type=int, required=True)
    c.add_argument("--y", type=int, required=True)
    c.add_argument("--button", default="left", choices=["left", "right"])
    c.add_argument("--double", action="store_true")
    c.add_argument("--hwnd", type=int)
    c.set_defaults(func=cmd_click)

    o = sub.add_parser("ocr")
    o.add_argument("--image", required=True)
    o.add_argument("--lang", default="en", choices=["en", "zh"])
    o.set_defaults(func=cmd_ocr)

    return p


def main():
    args = build_parser().parse_args()
    try:
        sys.exit(args.func(args))
    except Exception as exc:  # noqa: BLE001
        out(ok=False, error=f"{type(exc).__name__}: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
