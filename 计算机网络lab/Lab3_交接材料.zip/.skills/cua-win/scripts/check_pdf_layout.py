#!/usr/bin/env python
"""check_pdf_layout.py - find pagination problems in a rendered PDF.

Reports, per page, how much vertical space is left blank at the bottom and which
pages carry figures. Large trailing gaps usually mean a stray page break or a
figure that could not fit; they are what make a report look padded.

Usage: python check_pdf_layout.py report.pdf [--gap-threshold 250]
Exit code: 0 = no page exceeds the threshold, 1 = at least one does.
"""
import argparse
import sys

import fitz
import numpy as np


def analyse(path, threshold=250, dpi=100):
    doc = fitz.open(path)
    rows = []
    for pno, page in enumerate(doc, 1):
        pix = page.get_pixmap(dpi=dpi)
        arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
        gray = arr[:, :, :3].mean(axis=2)
        top = int(0.10 * gray.shape[0])      # skip header band
        bottom = int(0.93 * gray.shape[0])   # skip footer band
        body = gray[top:bottom, int(0.04 * gray.shape[1]):int(0.96 * gray.shape[1])]
        dark_rows = (body < 200).sum(axis=1)
        content = np.where(dark_rows > 2)[0]
        last = int(content[-1]) if len(content) else 0
        trailing = body.shape[0] - last
        images = len(page.get_images(full=True))
        # The LAST page legitimately ends mid-page, so trailing space there is
        # expected and must not be reported as a layout defect.
        is_last = pno == doc.page_count
        rows.append({"page": pno, "trailing_blank_px": trailing, "images": images,
                     "last_page": is_last,
                     "over_threshold": (trailing > threshold) and not is_last})
    return doc.page_count, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf", nargs="+")
    ap.add_argument("--gap-threshold", type=int, default=250)
    args = ap.parse_args()

    worst = 0
    for path in args.pdf:
        pages, rows = analyse(path, args.gap_threshold)
        print(f"\n{path}  ({pages} pages, threshold {args.gap_threshold}px)")
        for r in rows:
            flag = "  <== large gap" if r["over_threshold"] else ""
            img = f"  [{r['images']} image(s)]" if r["images"] else ""
            tail = "  (last page)" if r["last_page"] else ""
            print(f"   page {r['page']:2d}  trailing_blank={r['trailing_blank_px']:4d}px"
                  f"{img}{tail}{flag}")
        gaps = [r["page"] for r in rows if r["over_threshold"]]
        print(f"   pages over threshold: {gaps if gaps else 'none'}")
        if gaps:
            print("   HINT: a mid-document page this empty usually means a stray "
                  "page break or a figure that could not fit.")
        worst += len(gaps)
    return 1 if worst else 0


if __name__ == "__main__":
    sys.exit(main())
