#!/usr/bin/env python
"""check_pdf_fonts.py - detect fonts LibreOffice/Word substituted into a PDF.

A CJK font without a real bold face (e.g. SimSun) makes the renderer swap in a
*different* typeface for some glyphs. The result is text that looks blotchy and
uneven ("粗粗细细") while the DOCX itself looks fine. This script is the detector.

Usage: python check_pdf_fonts.py report.pdf [more.pdf ...]
Exit code: 0 = clean, 1 = substitutions found.
"""
import sys

import fitz

SUBSTITUTE_HINTS = (
    "Gothic", "JhengHei", "Calibri", "Batang", "MingLiU", "PMingLiU",
    "MSung", "DFKai", "Arial", "Helvetica", "Liberation", "DejaVu",
)

# Faces that are legitimately part of a scheme: list yours here to silence.
# (e.g. an intentional Latin face other than Times New Roman.)
ALLOWED = set()


def main(paths):
    bad_total = 0
    for path in paths:
        doc = fitz.open(path)
        fonts = {}
        for pno, page in enumerate(doc, 1):
            for f in page.get_fonts():
                fonts.setdefault(f[3], set()).add(pno)
        print(f"\n{path}  ({doc.page_count} pages)")
        bad = []
        for name in sorted(fonts):
            pages = sorted(fonts[name])
            short = name.split("+")[-1]
            flagged = any(h in short for h in SUBSTITUTE_HINTS) and short not in ALLOWED
            if flagged:
                bad.append((short, pages))
            print(f"   {'!!' if flagged else '  '} {short:34s} pages={pages}")
        print(f"   substituted faces: {len(bad)}")
        for name, pages in bad:
            print(f"      -> {name}  (pages {pages})")
        bad_total += len(bad)
        if bad:
            print("   FIX: use a family with a real bold face (Microsoft YaHei / "
                  "DengXian) and set fonts on RUNS, not only on styles.")
    print(f"\nTOTAL substituted faces: {bad_total}")
    return 1 if bad_total else 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    sys.exit(main(sys.argv[1:]))
