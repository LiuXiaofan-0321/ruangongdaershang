#!/usr/bin/env python
"""mcp_server.py - Model Context Protocol server exposing the cua-win toolkit.

Why this exists: MCP is how ZCode / OpenCode / Claude Desktop / Cursor discover
tools at runtime. This server is a THIN wrapper - every tool just calls
`cua.py <subcommand>` and returns its JSON. There is no hidden state, so the
same capability is equally usable straight from a shell.

Transport: stdio, JSON-RPC 2.0, MCP protocol revision 2024-11-05.
No third-party dependencies (stdlib only) so it runs under any Python 3.9+.

Register it, e.g. for an MCP-capable client:
  {
    "mcpServers": {
      "cua-win": { "command": "python", "args": ["<abs path>/mcp_server.py"] }
    }
  }

Self-check without a client:
  python mcp_server.py --selftest
"""
from __future__ import annotations

import json
import os
import subprocess
import sys

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

HERE = os.path.dirname(os.path.abspath(__file__))
CUA = os.path.join(HERE, "cua.py")
PROTOCOL_VERSION = "2024-11-05"
SERVER_INFO = {"name": "cua-win", "version": "1.0.0"}


def call_cua(args, timeout=90):
    """Run cua.py and return its parsed JSON object."""
    try:
        p = subprocess.run([sys.executable, CUA, *args], capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"cua.py timed out after {timeout}s"}
    line = p.stdout.strip().splitlines()[-1] if p.stdout.strip() else ""
    try:
        return json.loads(line)
    except Exception:
        return {"ok": False, "error": "unparseable cua.py output",
                "stdout": p.stdout[-500:], "stderr": p.stderr[-500:]}


TOOLS = [
    {
        "name": "cua_init",
        "description": "Initialise the toolkit and report DPI mode plus the real "
                       "(physical) screen size. Call this once before other tools.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "cua_windows",
        "description": "List visible top-level windows with hwnd, title, class, "
                       "process, physical-pixel rect and foreground flag.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "case-insensitive title filter"},
                "process": {"type": "string", "description": "process name filter"},
            },
        },
    },
    {
        "name": "cua_find",
        "description": "Find a window by title and return the best match (prefers the "
                       "foreground window) plus all matches.",
        "inputSchema": {
            "type": "object",
            "properties": {"title": {"type": "string"}},
            "required": ["title"],
        },
    },
    {
        "name": "cua_focus",
        "description": "Bring a window to the foreground and verify it. Must succeed "
                       "before typing/keys/clicking, because input goes to the "
                       "foreground window.",
        "inputSchema": {
            "type": "object",
            "properties": {"hwnd": {"type": "integer"}, "title": {"type": "string"}},
        },
    },
    {
        "name": "cua_screenshot",
        "description": "Capture the screen (or one window, or a crop) to a PNG and "
                       "return its path and size. Uses a full-screen grab because "
                       "PrintWindow returns blank/stale content for many windows.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "out": {"type": "string", "description": "output PNG path"},
                "hwnd": {"type": "integer", "description": "crop to this window"},
                "crop": {"type": "string", "description": "x,y,w,h"},
                "max_width": {"type": "integer", "default": 1600},
            },
        },
    },
    {
        "name": "cua_type",
        "description": "Enter text into the focused window. Default method 'clipboard' "
                       "is IME-proof; 'keys' injects keystrokes and CAN BE MANGLED by a "
                       "Chinese IME (digits get swallowed).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "hwnd": {"type": "integer"},
                "method": {"type": "string", "enum": ["clipboard", "keys"],
                           "default": "clipboard"},
                "clear": {"type": "boolean", "description": "select-all then type"},
            },
            "required": ["text"],
        },
    },
    {
        "name": "cua_key",
        "description": "Send key combinations, e.g. ['ctrl+shift+r', 'alt+f4', 'enter'].",
        "inputSchema": {
            "type": "object",
            "properties": {
                "keys": {"type": "array", "items": {"type": "string"}},
                "hwnd": {"type": "integer"},
            },
            "required": ["keys"],
        },
    },
    {
        "name": "cua_click",
        "description": "Move the pointer and click at physical-pixel coordinates. "
                       "Returns which window/control was under the point.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "x": {"type": "integer"},
                "y": {"type": "integer"},
                "button": {"type": "string", "enum": ["left", "right"], "default": "left"},
                "double": {"type": "boolean"},
                "hwnd": {"type": "integer", "description": "focus this window first"},
            },
            "required": ["x", "y"],
        },
    },
    {
        "name": "cua_ocr",
        "description": "OCR an image with the Windows built-in engine and return "
                       "recognised lines with coordinates. Requires: pip install winsdk.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "image": {"type": "string"},
                "lang": {"type": "string", "enum": ["en", "zh"], "default": "en"},
            },
            "required": ["image"],
        },
    },
]


def dispatch(name, args):
    """Map an MCP tool call onto a cua.py invocation."""
    args = args or {}
    if name == "cua_init":
        return call_cua(["init"])
    if name == "cua_windows":
        cmd = ["windows"]
        if args.get("title"):
            cmd += ["--title", str(args["title"])]
        if args.get("process"):
            cmd += ["--process", str(args["process"])]
        return call_cua(cmd)
    if name == "cua_find":
        return call_cua(["find", "--title", str(args["title"])])
    if name == "cua_focus":
        cmd = ["focus"]
        if args.get("hwnd"):
            cmd += ["--hwnd", str(args["hwnd"])]
        if args.get("title"):
            cmd += ["--title", str(args["title"])]
        return call_cua(cmd)
    if name == "cua_screenshot":
        cmd = ["shot"]
        if args.get("out"):
            cmd += ["--out", str(args["out"])]
        if args.get("hwnd"):
            cmd += ["--hwnd", str(args["hwnd"])]
        if args.get("crop"):
            cmd += ["--crop", str(args["crop"])]
        cmd += ["--max-width", str(args.get("max_width", 1600))]
        return call_cua(cmd)
    if name == "cua_type":
        cmd = ["type", "--text", str(args["text"]),
               "--method", args.get("method", "clipboard")]
        if args.get("hwnd"):
            cmd += ["--hwnd", str(args["hwnd"])]
        if args.get("clear"):
            cmd += ["--clear"]
        return call_cua(cmd)
    if name == "cua_key":
        cmd = ["key", "--keys", *[str(k) for k in args["keys"]]]
        if args.get("hwnd"):
            cmd += ["--hwnd", str(args["hwnd"])]
        return call_cua(cmd)
    if name == "cua_click":
        cmd = ["click", "--x", str(args["x"]), "--y", str(args["y"]),
               "--button", args.get("button", "left")]
        if args.get("double"):
            cmd += ["--double"]
        if args.get("hwnd"):
            cmd += ["--hwnd", str(args["hwnd"])]
        return call_cua(cmd)
    if name == "cua_ocr":
        return call_cua(["ocr", "--image", str(args["image"]),
                         "--lang", args.get("lang", "en")])
    return {"ok": False, "error": f"unknown tool {name}"}


def result(msg_id, payload, is_error=False):
    text = json.dumps(payload, ensure_ascii=False)
    return {"jsonrpc": "2.0", "id": msg_id,
            "result": {"content": [{"type": "text", "text": text}],
                       "isError": bool(is_error)}}


def handle(msg):
    method = msg.get("method")
    msg_id = msg.get("id")

    if method == "initialize":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": SERVER_INFO}}
    if method in ("notifications/initialized", "initialized"):
        return None
    if method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {"tools": TOOLS}}
    if method == "tools/call":
        params = msg.get("params") or {}
        payload = dispatch(params.get("name"), params.get("arguments"))
        return result(msg_id, payload, is_error=not payload.get("ok", True))
    if msg_id is None:
        return None
    return {"jsonrpc": "2.0", "id": msg_id,
            "error": {"code": -32601, "message": f"method not found: {method}"}}


def serve():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception:
            print(json.dumps({"jsonrpc": "2.0", "id": None,
                              "error": {"code": -32700, "message": "parse error"}}),
                  flush=True)
            continue
        resp = handle(msg)
        if resp is not None:
            print(json.dumps(resp, ensure_ascii=False), flush=True)


def selftest():
    checks = []
    r = handle({"jsonrpc": "2.0", "id": 1, "method": "initialize"})
    checks.append(("initialize", r["result"]["serverInfo"]["name"] == "cua-win"))
    r = handle({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
    names = [t["name"] for t in r["result"]["tools"]]
    checks.append(("tools/list", len(names) == len(TOOLS)))
    r = handle({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": "cua_init", "arguments": {}}})
    payload = json.loads(r["result"]["content"][0]["text"])
    checks.append(("tools/call cua_init", bool(payload.get("ok"))))
    r = handle({"jsonrpc": "2.0", "id": 4, "method": "tools/call",
                "params": {"name": "cua_windows",
                           "arguments": {"process": "explorer"}}})
    payload = json.loads(r["result"]["content"][0]["text"])
    checks.append(("tools/call cua_windows", payload.get("ok") is True))
    r = handle({"jsonrpc": "2.0", "id": 5, "method": "nope"})
    checks.append(("unknown method -> error", "error" in r))

    ok = all(c[1] for c in checks)
    print(json.dumps({"ok": ok, "tools": names,
                      "checks": [{"check": c[0], "pass": c[1]} for c in checks]},
                     ensure_ascii=False, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    serve()
