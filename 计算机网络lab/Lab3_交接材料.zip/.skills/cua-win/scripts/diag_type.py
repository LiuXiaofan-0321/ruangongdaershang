# -*- coding: utf-8 -*-
"""diag_type.py - find which text-injection method actually reaches an editor.

Reports, for each method, what the target window contains afterwards (read back
through the editor's own UI Automation ValuePattern where available, otherwise a
screenshot + OCR).

Usage: python diag_type.py [--target notepad]
"""
import ctypes
import json
import os
import subprocess
import sys
import tempfile
import time
from ctypes import wintypes

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

ULONG_PTR = ctypes.c_uint64 if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_uint32
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_SCANCODE = 0x0008


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_uint32), ("time", ctypes.c_uint32),
                ("dwExtraInfo", ULONG_PTR)]


class _U(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("pad", ctypes.c_ubyte * 24)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.c_uint32), ("u", _U)]


def focus(hwnd):
    fg = user32.GetForegroundWindow()
    t_fg = user32.GetWindowThreadProcessId(fg, None)
    t_me = kernel32.GetCurrentThreadId()
    att = False
    if t_fg and t_fg != t_me:
        att = bool(user32.AttachThreadInput(t_me, t_fg, True))
    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
        user32.SetFocus(hwnd)
        time.sleep(0.2)
        if user32.GetForegroundWindow() != hwnd:
            user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0002 | 0x0001 | 0x0040)
            user32.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0002 | 0x0001 | 0x0040)
            user32.SetForegroundWindow(hwnd)
            time.sleep(0.2)
    finally:
        if att:
            user32.AttachThreadInput(t_me, t_fg, False)
    return user32.GetForegroundWindow() == hwnd


def method_sendinput_unicode(text):
    for ch in text:
        for flags in (KEYEVENTF_UNICODE, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP):
            inp = INPUT(type=INPUT_KEYBOARD)
            inp.u.ki = KEYBDINPUT(0, ord(ch), flags, 0, 0)
            user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        time.sleep(0.01)


VK_MAP = {}

def _fill_vk():
    import string
    for c in string.ascii_uppercase:
        VK_MAP[c] = ord(c)
    for c in string.digits:
        VK_MAP[c] = ord(c)
    VK_MAP[" "] = 0x20
    VK_MAP["."] = 0xBE
    VK_MAP[":"] = 0xBA
    VK_MAP["0"] = 0x30


def method_keybd_event_vk(text):
    _fill_vk()
    for ch in text:
        up = ch.upper()
        vk = VK_MAP.get(ch) or VK_MAP.get(up)
        if vk is None:
            continue
        shift = ch.isupper()
        if shift:
            user32.keybd_event(0x10, 0, 0, 0)
        user32.keybd_event(vk, 0, 0, 0)
        user32.keybd_event(vk, 0, 2, 0)
        if shift:
            user32.keybd_event(0x10, 0, 2, 0)
        time.sleep(0.012)


def method_pyautogui(text):
    import pyautogui
    pyautogui.typewrite(text, interval=0.02)


def read_value_uia(hwnd):
    """Read the focused window's text via UI Automation ValuePattern, if any."""
    try:
        import comtypes.client
    except ImportError:
        return None
    try:
        comtypes.client.GetModule("UIAutomationCore.dll")
        from comtypes.gen import UIAutomationClient as UIA
        ui = comtypes.client.CreateObject(UIA.CUIAutomation, interface=UIA.IUIAutomation)
        cond = ui.CreatePropertyCondition(UIA.UIA_NativeWindowHandlePropertyId, int(hwnd))
        el = ui.GetRootElement().FindFirst(UIA.TreeScope.TreeScope_Children, cond)
        if not el:
            return None
        els = el.FindAll(UIA.TreeScope.TreeScope_Descendants, ui.CreateTrueCondition())
        values = []
        for i in range(els.Length):
            e = els.GetElement(i)
            try:
                pat = e.GetCurrentPattern(UIA.UIA_ValuePatternId)
                values.append(pat.QueryInterface(UIA.IUIAutomationValuePattern).CurrentValue)
            except Exception:
                continue
        return values
    except Exception as exc:  # noqa: BLE001
        return [f"<uia error: {exc}>"]


def main():
    tmp = tempfile.mkdtemp(prefix="cua-diag-")
    scratch = os.path.join(tmp, "diag.txt")
    open(scratch, "w", encoding="utf-8").close()
    subprocess.Popen(["notepad.exe", scratch])
    time.sleep(4.0)

    # locate window by title
    target = None
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _l):
        nonlocal target
        if user32.IsWindowVisible(h):
            n = user32.GetWindowTextLengthW(h)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(h, buf, n + 1)
                if "diag.txt" in buf.value:
                    target = h
        return True

    user32.EnumWindows(EnumProc(cb), 0)
    if not target:
        print(json.dumps({"ok": False, "error": "notepad window not found"}))
        return 1

    results = []
    methods = [
        ("SendInput KEYEVENTF_UNICODE", method_sendinput_unicode),
        ("keybd_event VK", method_keybd_event_vk),
        ("pyautogui.typewrite", method_pyautogui),
    ]
    for name, fn in methods:
        # start from a clean buffer each round
        focus(target)
        user32.keybd_event(0x11, 0, 0, 0); user32.keybd_event(0x41, 0, 0, 0)
        user32.keybd_event(0x41, 0, 2, 0); user32.keybd_event(0x11, 0, 2, 0)
        time.sleep(0.2)
        user32.keybd_event(0x2E, 0, 0, 0); user32.keybd_event(0x2E, 0, 2, 0)
        time.sleep(0.3)

        focus(target)
        probe = f"M{len(results)}ABC123"
        t0 = time.time()
        try:
            fn(probe)
            err = None
        except Exception as exc:  # noqa: BLE001
            err = f"{type(exc).__name__}: {exc}"
        time.sleep(0.6)
        vals = read_value_uia(target)
        results.append({
            "method": name,
            "sent": probe,
            "error": err,
            "uia_values": vals,
            "seconds": round(time.time() - t0, 2),
        })

    # leave notepad open for manual inspection, print where it is
    print(json.dumps({"ok": True, "window": int(target), "scratch": scratch,
                      "results": results}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
