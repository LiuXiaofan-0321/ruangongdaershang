# -*- coding: utf-8 -*-
"""selftest_docx.py - build a small report with DocBuilder and run the three
verification scripts on it, proving the whole DOCX pipeline end to end.

Usage: python selftest_docx.py
"""
import glob
import json
import os
import subprocess
import sys
import tempfile

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from build_docx_helpers import DocBuilder  # noqa: E402

PY = sys.executable
SOFFICE_CANDIDATES = glob.glob(os.path.expanduser(
    r"~\AppData\Local\LibreOffice-*\program\soffice.exe"))
KIT_CLI = (r"C:\Users\18963\AppData\Local\Programs\DeepSeek Harness\resources"
           r"\app.asar.unpacked\dsh\node_modules\@deepseek-ai\libreoffice-kit\lib\cli.js")
KIT_NODE = (r"C:\Users\18963\AppData\Local\Programs\DeepSeek Harness\resources"
            r"\runtime\primary-runtime\dependencies\node\bin\node.exe")


def convert_with_system_libreoffice(docx, outdir):
    if not SOFFICE_CANDIDATES:
        return None, "no system LibreOffice found"
    exe = SOFFICE_CANDIDATES[0]
    profile = "file:///" + tempfile.mkdtemp(prefix="lo-selftest-").replace("\\", "/")
    p = subprocess.run([exe, "--headless", f"-env:UserInstallation={profile}",
                        "--convert-to", "pdf", "--outdir", outdir, docx],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    pdf = os.path.join(outdir, os.path.splitext(os.path.basename(docx))[0] + ".pdf")
    return (pdf, None) if os.path.isfile(pdf) else (None, p.stderr[-300:])


def run_script(name, args):
    p = subprocess.run([PY, os.path.join(HERE, name), *args], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    return p.returncode, p.stdout


def main():
    tmp = tempfile.mkdtemp(prefix="docx-selftest-")
    b = DocBuilder("测试实验报告", "skill 自检", "页眉：字体与排版自检")
    b.head("一、实验目的", 1)
    b.para("本段用于验证中文与 Latin 混排（Ethernet II, 74 B）、标点（"
           "，。；：（）「」）以及加粗是否均匀。")
    b.para("加粗强调：目的 MAC 为下一跳网关。", bold=True)
    b.head("4.1  字段表", 2)
    b.table(["字段", "偏移", "实测值"],
            [["目的 MAC", "0–5", "28:d1:27:df:d4:95"],
             ["源 MAC", "6–11", "14:ac:60:56:df:85"],
             ["Type", "12–13", "0x0800"]],
            [3.6, 3.0, 9.4])
    b.mono(["0000  28 d1 27 df d4 95 14 ac 60 56 df 85 08 00 45 00",
            "0010  00 3c 21 e6 00 00 80 01 00 00 c0 a8 1f 87 b4 65"])
    b.head("二、结果", 1)
    b.para("命令示例：", indent=False)
    b.mono(["tshark -r file.pcapng -Y llc -T fields -e frame.number"])
    # enough body text that the document spans >1 page, so the layout check is
    # meaningful (a single-page document always has a trailing gap).
    b.head("三、分析", 1)
    for i in range(14):
        b.para(f"第 {i + 1} 段：以太网帧首部固定 14 字节，其中目的 MAC 与源 MAC 各 6 字节，"
               f"类型字段 2 字节；IPv4 首部通常 20 字节，ICMP 首部 8 字节，实测记录 74 字节。"
               f"这一段用于撑满页面以验证分页与字体替换检查（Ethernet II, 0x0800）")
    docx = os.path.join(tmp, "selftest.docx")
    b.save(docx)

    steps = []

    rc, out = run_script("check_docx_fonts.py", ["--dir", tmp, "--latest"])
    ok = "fonts with FULL coverage:" in out and "none" not in out.split("FULL coverage:")[1][:8]
    steps.append(("check_docx_fonts", ok, out.strip().splitlines()[-1] if out else ""))

    pdf, err = convert_with_system_libreoffice(docx, tmp)
    steps.append(("convert to pdf (system LibreOffice)", bool(pdf), err or pdf))

    if pdf:
        rc, out = run_script("check_pdf_fonts.py", [pdf])
        bad = "TOTAL substituted faces: 0" in out
        steps.append(("check_pdf_fonts", bad,
                      [l for l in out.splitlines() if "substituted faces:" in l][-1:]))
        rc, out = run_script("check_pdf_layout.py", [pdf])
        no_gap = "pages over threshold: none" in out
        steps.append(("check_pdf_layout", no_gap,
                      [l for l in out.splitlines() if "over threshold" in l][-1:]))

    result = {"ok": all(s[1] for s in steps), "docx": docx, "pdf": pdf,
              "steps": [{"step": s[0], "pass": s[1], "detail": s[2]} for s in steps]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
