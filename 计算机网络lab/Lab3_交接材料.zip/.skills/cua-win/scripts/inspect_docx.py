# -*- coding: utf-8 -*-
"""inspect_docx.py - show a DOCX's paragraphs, tables, images and captions.

Usage: python inspect_docx.py --dir <folder> [--match RE] [--full]
       python inspect_docx.py <path.docx> [--full]
"""
import argparse
import glob
import os
import re
import sys
import zipfile

from docx import Document

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def resolve(args):
    paths = list(args.paths)
    if args.dir:
        for f in sorted(glob.glob(os.path.join(args.dir, "*.docx"))):
            if args.match and not re.search(args.match, os.path.basename(f), re.I):
                continue
            if not os.path.basename(f).startswith("~$"):
                paths.append(f)
    return paths


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="*")
    ap.add_argument("--dir")
    ap.add_argument("--match")
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--max-para", type=int, default=200)
    args = ap.parse_args()

    for path in resolve(args):
        if not os.path.isfile(path):
            print(f"SKIP (not found): {path}")
            continue
        z = zipfile.ZipFile(path)
        media = sorted(n for n in z.namelist() if n.startswith("word/media/"))
        d = Document(path)
        print("=" * 78)
        print(f"FILE   : {path}")
        print(f"SIZE   : {round(os.path.getsize(path)/1024, 1)} KB")
        print(f"paras  : {len(d.paragraphs)}   tables: {len(d.tables)}   images: {len(media)}")
        print(f"media  :")
        for m in media:
            print(f"         {os.path.basename(m):26s} {round(z.getinfo(m).file_size/1024,1):>8} KB")
        print("--- paragraph / caption / image order ---")
        body = d.element.body
        n_img = 0
        count = 0
        for child in body.iterchildren():
            tag = child.tag.split('}')[-1]
            if tag == "p":
                from docx.text.paragraph import Paragraph
                para = Paragraph(child, d)
                text = para.text.strip()
                has_img = bool(child.findall(".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip"))
                if has_img:
                    n_img += 1
                    print(f"  [{n_img:2d}] <<IMAGE>>   (paragraph has no text)" if not text else
                          f"  [{n_img:2d}] <<IMAGE>>   {text[:60]}")
                elif text:
                    style = para.style.name
                    mark = "CAP" if style == "Caption" else ("H" + style[-1] if style.startswith("Heading") else "   ")
                    if args.full or count < args.max_para:
                        print(f"       {mark:>4}  {text[:74]}")
                    count += 1
            elif tag == "tbl":
                print("        [TABLE]")
        print()


if __name__ == "__main__":
    main()
