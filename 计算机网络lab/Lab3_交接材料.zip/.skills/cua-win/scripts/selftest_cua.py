# -*- coding: utf-8 -*-
"""selftest_cua.py - prove the CUA primitives actually drive the real desktop.

Verification uses the target editor's own text value (UI Automation
ValuePattern) as well as a screenshot, because on this host an active IME can
mangle injected keystrokes - so "the call returned ok" is NOT evidence.

Usage: python selftest_cua.py
"""
import ctypes
import json
import os
import subprocess
import sys
import tempfile
import time
from ctypes import wintypes

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PY = sys.executable
HERE = os.path.dirname(os.path.abspath(__file__))
CUA = os.path.join(HERE, "cua.py")
PROBE = "CUA probe 74B 0x0800"

user32 = ctypes.windll.user32
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass


def run(*args):
    p = subprocess.run([PY, CUA, *args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    try:
        return json.loads(p.stdout.strip().splitlines()[-1])
    except Exception:
        return {"ok": False, "raw": p.stdout[-400:], "err": p.stderr[-400:]}


def read_text_uia(hwnd):
    """Read the window's text through UI Automation (independent of pixels)."""
    try:
        import comtypes.client
        comtypes.client.GetModule("UIAutomationCore.dll")
        from comtypes.gen import UIAutomationClient as UIA
        ui = comtypes.client.CreateObject(UIA.CUIAutomation, interface=UIA.IUIAutomation)
        cond = ui.CreatePropertyCondition(UIA.UIA_NativeWindowHandlePropertyId, int(hwnd))
        el = ui.GetRootElement().FindFirst(UIA.TreeScope.TreeScope_Children, cond)
        if not el:
            return {"error": "window not exposed via UIA"}
        els = el.FindAll(UIA.TreeScope.TreeScope_Descendants, ui.CreateTrueCondition())
        texts = []
        for i in range(els.Length):
            e = els.GetElement(i)
            try:
                pat = e.GetCurrentPattern(UIA.UIA_ValuePatternId)
                texts.append(pat.QueryInterface(UIA.IUIAutomationValuePattern).CurrentValue)
            except Exception:
                continue
        return {"values": texts}
    except Exception as exc:  # noqa: BLE001
        return {"error": f"{type(exc).__name__}: {exc}"}


def main():
    tmp = tempfile.mkdtemp(prefix="cua-selftest-")
    scratch = os.path.join(tmp, "cua-selftest.txt")
    open(scratch, "w", encoding="utf-8").close()

    steps = []
    init = run("init")
    steps.append(("init", init.get("ok"), init))

    subprocess.Popen(["notepad.exe", scratch])
    time.sleep(4.0)

    found = run("find", "--title", "cua-selftest")
    hwnd = (found.get("match") or {}).get("hwnd")
    steps.append(("find window", bool(hwnd), found.get("match")))
    if not hwnd:
        print(json.dumps({"ok": False, "steps": steps}, ensure_ascii=False, indent=2))
        return 1

    foc = run("focus", "--hwnd", str(hwnd))
    steps.append(("focus", bool(foc.get("ok")) and foc.get("foreground") == hwnd, foc))

    typ = run("type", "--text", PROBE, "--hwnd", str(hwnd), "--method", "clipboard")
    steps.append(("type (clipboard)", typ.get("ok"), typ))
    time.sleep(0.7)

    uia = read_text_uia(hwnd)
    values = uia.get("values", [])
    landed_uia = any(PROBE in (v or "") for v in values)
    steps.append(("read back via UIA", landed_uia, uia))

    shot = run("shot", "--hwnd", str(hwnd), "--out",
               os.path.join(tmp, "after-type.png"), "--max-width", "1500")
    steps.append(("screenshot", shot.get("ok"), shot))

    ocr = run("ocr", "--image", shot.get("path", ""), "--lang", "en")
    joined = " ".join(l["text"] for l in ocr.get("lines", []))
    landed_ocr = ("CUA probe" in joined) or ("0x0800" in joined)
    steps.append(("read back via OCR", landed_ocr, {"lines": [l["text"] for l in ocr.get("lines", [])][:8]}))

    run("focus", "--hwnd", str(hwnd))
    run("key", "--keys", "alt+f4")
    time.sleep(1.2)

    result = {"ok": all(s[1] for s in steps), "probe": PROBE, "scratch": scratch,
              "steps": [{"step": s[0], "pass": s[1], "detail": s[2]} for s in steps]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
