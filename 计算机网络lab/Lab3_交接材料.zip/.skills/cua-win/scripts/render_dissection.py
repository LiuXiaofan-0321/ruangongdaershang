# -*- coding: utf-8 -*-
"""render_dissection.py - render `tshark -V` output as a printable dissection figure.

Wireshark's GUI protocol tree is hard to capture legibly (the tree pane is small
and PrintWindow is unreliable), so for deep field tables we render the SAME
dissector output as a clean monospaced image. Label such a figure as "Wireshark
dissector output", never as a screenshot.

Usage:
  python render_dissection.py --pcap f.pcapng --filter "frame.number==1" --out fig.png \
      --title "帧 1 协议解析（Wireshark 4.6.8）" [--max-lines 60] [--keep-tags]
"""
import argparse
import os
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TSHARK_CANDIDATES = [
    r"C:\Program Files\Wireshark\tshark.exe",
    r"C:\Program Files (x86)\Wireshark\tshark.exe",
]

FONT = r"C:\Windows\Fonts\consola.ttf"
FONT_CN = r"C:\Windows\Fonts\msyh.ttc"
SIZE = 21
LINE_H = 30
PAD = 28


def find_tshark():
    for c in TSHARK_CANDIDATES:
        if os.path.isfile(c):
            return c
    raise SystemExit("tshark not found")


def get_dissection(pcap, filt, keep_tags=False):
    cmd = [find_tshark(), "-r", pcap, "-V"]
    if filt:
        cmd += ["-Y", filt]
    p = subprocess.run(cmd, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    lines = p.stdout.splitlines()
    out = []
    for ln in lines:
        if not ln.strip():
            continue
        indent = len(ln) - len(ln.lstrip())
        body = ln.strip()
        if not keep_tags and body.startswith("["):
            continue                       # generated fields, not on the wire
        out.append(("    " * (indent // 4)) + body)
    return out


def render(lines, out_path, title, max_lines, dpi_scale=2):
    f = ImageFont.truetype(FONT, SIZE)
    fcn = ImageFont.truetype(FONT_CN, SIZE + 2)
    ftitle = ImageFont.truetype(FONT_CN, SIZE + 8)
    lines = lines[:max_lines]
    width = max([int(f.getlength(l)) for l in lines] + [int(ftitle.getlength(title))]) + PAD * 2
    height = PAD * 2 + 44 + len(lines) * LINE_H
    img = Image.new("RGB", (int(width * 1.04), height), "white")
    dr = ImageDraw.Draw(img)
    dr.text((PAD, PAD), title, font=ftitle, fill="#111111")
    y = PAD + 50
    for ln in lines:
        # use the CJK face when the line contains CJK, else the mono face
        font = fcn if any("\u4e00" <= ch <= "\u9fff" for ch in ln) else f
        color = "#0B3D0B" if ln.strip().startswith(("Frame ", "Ethernet", "Internet",
                                                    "Internet Control", "Logical",
                                                    "Address Resolution")) else "#1A1A1A"
        dr.text((PAD, y), ln, font=font, fill=color)
        y += LINE_H
    img.save(out_path)
    return out_path, img.size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pcap", required=True)
    ap.add_argument("--filter", default="")
    ap.add_argument("--out", required=True)
    ap.add_argument("--title", default="Wireshark 协议解析输出")
    ap.add_argument("--max-lines", type=int, default=60)
    ap.add_argument("--keep-tags", action="store_true")
    ap.add_argument("--print", action="store_true", help="also print the text")
    args = ap.parse_args()

    lines = get_dissection(args.pcap, args.filter, args.keep_tags)
    path, size = render(lines, args.out, args.title, args.max_lines)
    print(f"RENDERED {path}  size={size}  lines={min(len(lines), args.max_lines)}"
          f"  (total {len(lines)})")
    if args.print:
        print("\n".join(lines[:args.max_lines]))


if __name__ == "__main__":
    main()
