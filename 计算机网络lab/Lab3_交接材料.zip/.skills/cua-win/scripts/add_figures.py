# -*- coding: utf-8 -*-
"""add_figures.py - insert evidence screenshots into the Lab2 report by POSITION,
then renumber all figure captions sequentially and fix in-text references.

Position-based (not text-anchor-based) insertion: anchors matched by phrase are
fragile and made the figures land in the wrong place during testing. The indices
below are computed from the document's own paragraph list, so the plan is printed
before anything is written.

Usage:
  python add_figures.py --doc <report.docx> --shots <dir> [--out F] [--plan-only]
"""
import argparse
import os
import re
import sys

import docx
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from docx.text.paragraph import Paragraph

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BLIP = "{http://schemas.openxmlformats.org/drawingml/2006/main}blip"
LATIN = "Times New Roman"
CJK = "Microsoft YaHei"


def paragraphs(doc):
    return [Paragraph(el, doc) for el in doc.element.body.iterchildren()
            if el.tag.split("}")[-1] == "p"]


def is_image(para):
    return bool(para._p.findall(f".//{BLIP}"))


def is_caption(para):
    return para.style.name == "Caption" and para.text.strip().startswith("图")


def build_figure(doc, path, width_cm, caption):
    """Append an image paragraph + caption via python-docx, then RETURN their
    elements so the caller can MOVE them into place with addnext().

    Do not build these paragraphs with makeelement(): add_picture() then fails to
    register the image relationship properly, which produced two figures sharing
    one media part and a body/manifest image-count mismatch during testing.
    """
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(path, width=Cm(width_cm))

    cap = doc.add_paragraph(caption, style="Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in cap.runs:
        r.font.size = Pt(9)
        r.font.name = LATIN
        r.font.bold = False
        r.font.color.rgb = RGBColor(0, 0, 0)
        r._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), CJK)
    return p._p, cap._p


def renumber(doc):
    """Sequentially number every caption (matching '图 <number|X>')."""
    n, mapping = 0, {}
    for para in paragraphs(doc):
        if para.style.name != "Caption":
            continue
        m = re.match(r"\s*图\s*([0-9]+|X)\s*", para.text)
        if not m:
            continue
        old_raw = m.group(1)
        n += 1
        old = int(old_raw) if old_raw.isdigit() else None
        if old != n:
            if old is not None:
                mapping[old] = n
            for run in para.runs:
                if re.search(r"图\s*([0-9]+|X)", run.text):
                    run.text = re.sub(r"图\s*([0-9]+|X)", f"图 {n}", run.text, count=1)
                    break
    return n, mapping


def fix_refs(doc, mapping):
    """Rewrite in-text '图 N' references, but NEVER touch figure ranges.

    '教材图 4-14' is a citation of the textbook's figure 4-14, not a reference to
    this report's figure 4. Rewriting it to '图 8-14' silently corrupts the text
    (this happened on the first run), so a number followed by '-' or '–' is left
    alone.
    """
    PAT = r"图\s*(\d+)(?!\s*[-–—])"
    changed = []
    for para in paragraphs(doc):
        if para.style.name == "Caption":
            continue
        nums = [int(x) for x in re.findall(PAT, para.text)]
        if not nums or any(x not in mapping for x in nums):
            continue
        before = para.text
        for run in para.runs:
            if re.search(PAT, run.text):
                run.text = re.sub(PAT,
                                  lambda m: f"图 {mapping[int(m.group(1))]}", run.text)
        if para.text != before:
            changed.append((before[:46], para.text[:46]))
    return changed


def verify(doc):
    """Report figure order and any caption not preceded by an image."""
    seq, problems, pending = [], [], False
    for para in paragraphs(doc):
        if is_image(para):
            pending = True
            continue
        if is_caption(para):
            m = re.match(r"图\s*(\d+)", para.text.strip())
            seq.append(int(m.group(1)) if m else -1)
            if not pending:
                problems.append(para.text.strip()[:56])
            pending = False
        elif para.text.strip():
            pending = False
        if is_caption(para):
            continue
    sequential = seq == list(range(1, len(seq) + 1))
    return sequential and not problems, seq, problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--doc", required=True)
    ap.add_argument("--shots", required=True)
    ap.add_argument("--out")
    ap.add_argument("--plan-only", action="store_true")
    args = ap.parse_args()

    def shot(name):
        p = os.path.join(args.shots, name)
        if not os.path.isfile(p):
            raise SystemExit(f"missing image: {p}")
        return p

    doc = docx.Document(args.doc)
    # locate the 6 original images by their caption keywords
    keys = {
        "f1": ("本次捕获共 8 帧", "图 1"),
        "f2": ("帧 1 的字节布局", "图 2"),
        "f3": ("地址的作用范围（实测地址）", "图 3"),
        "f4": ("11 个以太网广播帧", "图 4"),
        "f5": ("99 个普通组播帧", "图 5"),
        "f6": ("I/G 位（bit 0）", "图 6"),
    }
    paras = paragraphs(doc)
    cap_idx = {}
    for i, p in enumerate(paras):
        if p.style.name != "Caption":
            continue
        for k, (_a, capkey) in keys.items():
            if capkey in p.text:
                cap_idx[k] = i
    missing = [k for k in keys if k not in cap_idx]
    if missing:
        raise SystemExit(f"could not locate original captions: {missing}")

    # NOTE: 图 1 in the original document IS the Wireshark unicast list, so do not
    # insert another copy of it (that duplicated image1.png / re-used rId8).
    plan = [
        ("f1", "fig_ping.png", 14.0,
         "图 X  连通性验证：ping -4 -n 4 的 4 次请求全部收到回复，丢失 0%，"
         "并记录目标地址与往返时间（baidu 的 A 记录会轮转，此处地址与抓包时不同属正常）"),
        ("f2", "fig_dissection.png", 16.0,
         "图 X  Wireshark dissector 输出的帧 1 协议树：Ethernet II 展开为 "
         "Destination / Source / Type，并给出 IPv4 与 ICMP 各字段的实测取值"),
        ("f3", "fig_arp.png", 14.5,
         "图 X  arp -a 实测输出：接口 192.168.31.135 下默认网关 192.168.31.1 的"
         "物理地址为 28-d1-27-df-d4-95，与帧 1 的目的 MAC 完全一致"),
        ("f4", "gui_multicast_list.png", 16.0,
         "图 X  Wireshark 中筛选普通组播帧：eth.dst.ig == 1 && "
         "eth.dst != ff:ff:ff:ff:ff:ff"),
        ("f4", "gui_broadcast_ig.png", 16.0,
         "图 X  广播帧的 Destination 展开：IG bit 为 Group address "
         "(multicast/broadcast)，LG bit 为 Locally administered address"),
    ]

    print("PLAN (insert after the caption paragraph of):")
    for key, img, _w, _c in plan:
        print(f"  {key} (para {cap_idx[key]:>3})  <- {img}")
    if args.plan_only:
        return 0

    # apply in REVERSE caption order so earlier indices stay valid
    for key, img, width, caption in sorted(
            plan, key=lambda x: cap_idx[x[0]], reverse=True):
        paras = paragraphs(doc)
        anchor = paras[cap_idx[key]]._p
        img_el, cap_el = build_figure(doc, shot(img), width, caption)
        anchor.addnext(cap_el)
        anchor.addnext(img_el)

    total, mapping = renumber(doc)
    changed = fix_refs(doc, mapping)

    ok, seq, problems = verify(doc)
    out = args.out or args.doc
    doc.save(out)
    print(f"\nSAVED {out}")
    print(f"figures    : {total}")
    print(f"order      : {seq}")
    print(f"sequential : {seq == list(range(1, len(seq) + 1))}")
    print(f"renumbered : {mapping}")
    print(f"caption-without-image: {problems if problems else 'none'}")
    for a, b in changed:
        print(f"  ref: {a!r} -> {b!r}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
