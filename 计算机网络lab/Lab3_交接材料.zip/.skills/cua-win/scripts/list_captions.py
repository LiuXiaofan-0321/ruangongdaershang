# -*- coding: utf-8 -*-
"""list_captions.py - print a DOCX's figure captions in document order.

Usage: python list_captions.py --dir <folder> --match RE
"""
import argparse
import glob
import os
import re
import sys

from docx import Document
from docx.text.paragraph import Paragraph

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def iter_body(doc):
    for child in doc.element.body.iterchildren():
        tag = child.tag.split("}")[-1]
        if tag == "p":
            yield "p", Paragraph(child, doc)
        elif tag == "tbl":
            yield "tbl", child


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir")
    ap.add_argument("--match", default="")
    ap.add_argument("paths", nargs="*")
    args = ap.parse_args()

    paths = list(args.paths)
    if args.dir:
        for f in sorted(glob.glob(os.path.join(args.dir, "*.docx"))):
            if args.match and not re.search(args.match, os.path.basename(f), re.I):
                continue
            if not os.path.basename(f).startswith("~$"):
                paths.append(f)

    for path in paths:
        doc = Document(path)
        print("=" * 74)
        print(os.path.basename(path))
        n = 0
        for kind, item in iter_body(doc):
            if kind != "p":
                continue
            has_img = bool(item._p.findall(
                ".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip"))
            if has_img:
                n += 1
                print(f"  image #{n}")
            elif item.style.name == "Caption" and item.text.strip():
                print(f"      CAP: {item.text.strip()}")
            elif item.style.name.startswith("Heading") and item.text.strip():
                print(f"  H{item.style.name[-1]}: {item.text.strip()}")
        print(f"  total images in body: {n}")


if __name__ == "__main__":
    main()
