#!/usr/bin/env python
"""build_docx_helpers.py - python-docx helpers tuned for LibreOffice rendering.

Import it, don't run it:

    from build_docx_helpers import DocBuilder
    b = DocBuilder("华东师范大学软件学院实验报告", "Lab2 Ethernet")
    b.head("一、实验目的", 1)
    b.para("正文……")
    b.table(["字段", "实测值"], [["目的 MAC", "28:d1:27:df:d4:95"]], [4.0, 12.0])
    b.mono(["0000  28 d1 27 df d4 95 14 ac 60 56 df 85 08 00 45 00"])
    b.figure("fig1.png", "图 1  ……（说明这张图证明了什么）")
    b.save("report.docx")

Font policy (this is what fixes uneven Chinese text — see SKILL.md):
  * Latin = Times New Roman, CJK = a family with a REAL bold face.
    SimSun/宋体 has no bold; bolding it produces blotchy synthesized strokes and
    LibreOffice then substitutes other families glyph-by-glyph.
  * Bold text switches the CJK face to the same real-bold family.
  * Fonts are applied to RUNS, not only to styles: style-level East-Asian fonts
    were substituted for every heading in testing.
"""
from __future__ import annotations

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

LATIN = "Times New Roman"
CJK = "Microsoft YaHei"     # has a genuine bold face
CJK_BOLD = "Microsoft YaHei"
MONO = "Consolas"           # ASCII-only contexts (hex dumps, commands)


class DocBuilder:
    def __init__(self, title: str, subtitle: str = "", header_text: str = "",
                 page_header: bool = True, base_size: float = 10.5):
        self.base = base_size
        self.d = Document()
        self._setup_section()
        self._setup_styles()
        if title:
            self._title_block(title, subtitle)
        if page_header and header_text:
            p = self.d.sections[0].header.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            self._font(p.add_run(header_text), 8.5)

    # ---------------- setup ----------------
    def _setup_section(self):
        s = self.d.sections[0]
        s.page_width, s.page_height = Cm(21), Cm(29.7)
        s.top_margin, s.bottom_margin = Cm(2.0), Cm(1.9)
        s.left_margin, s.right_margin = Cm(2.3), Cm(2.3)
        s.header_distance, s.footer_distance = Cm(0.8), Cm(0.85)
        # page number field in the footer
        fp = s.footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        self._font(fp.add_run("第 "), 9)
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), "PAGE")
        r = OxmlElement("w:r")
        t = OxmlElement("w:t")
        t.text = "1"
        r.append(t)
        fld.append(r)
        fp._p.append(fld)
        self._font(fp.add_run(" 页"), 9)

    def _setup_styles(self):
        for name in ["Normal", "Title", "Subtitle", "Heading 1", "Heading 2",
                     "Heading 3", "Caption", "List Paragraph"]:
            st = self.d.styles[name]
            st.font.name = LATIN
            st._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), CJK)
            st.font.color.rgb = RGBColor(0, 0, 0)
        for nm, sz in [("Heading 1", 14), ("Heading 2", 12.5), ("Heading 3", 11.5)]:
            st = self.d.styles[nm]
            st.font.size = Pt(sz)
            st.font.bold = True
            st.font.name = CJK_BOLD
            st._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), CJK_BOLD)
            st.paragraph_format.first_line_indent = Cm(0)
            st.paragraph_format.space_before = Pt(9)
            st.paragraph_format.space_after = Pt(5)
            st.paragraph_format.keep_with_next = True
            st.paragraph_format.line_spacing = 1.25
        normal = self.d.styles["Normal"]
        normal.font.size = Pt(self.base)
        normal.paragraph_format.line_spacing = 1.3
        normal.paragraph_format.space_after = Pt(4)
        cap = self.d.styles["Caption"]
        cap.font.size = Pt(9)
        cap.font.name = LATIN
        cap._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), CJK)
        cap.paragraph_format.first_line_indent = Cm(0)
        cap.paragraph_format.space_after = Pt(8)
        # drop theme borders that LibreOffice renders inconsistently
        for el in self.d.styles._element.xpath(".//w:pBdr"):
            el.getparent().remove(el)

    def _title_block(self, title, subtitle):
        p = self.d.add_paragraph(style="Title")
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(6)
        self._font(p.add_run(title), 17, True, CJK_BOLD)
        if subtitle:
            p = self.d.add_paragraph(style="Subtitle")
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Cm(0)
            p.paragraph_format.space_after = Pt(8)
            self._font(p.add_run(subtitle), 11.5, True, CJK_BOLD)

    # ---------------- font helper ----------------
    def _font(self, run, size=None, bold=False, face=None, color="000000", mono=False):
        if mono:
            face = face or MONO
            latin = MONO
        else:
            face = face or (CJK_BOLD if bold else CJK)
            latin = face if bold else LATIN
        run.font.size = Pt(size if size is not None else self.base)
        run.font.bold = bool(bold)
        run.font.color.rgb = RGBColor.from_string(color)
        run.font.name = latin
        run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), face)

    # ---------------- content ----------------
    def head(self, text, level=1):
        """Heading with fonts on the RUN (style-level CJK fonts get substituted)."""
        size = {1: 14, 2: 12.5, 3: 11.5}.get(level, 11)
        p = self.d.add_paragraph(style=f"Heading {level}")
        self._font(p.add_run(text), size, True, CJK_BOLD)
        return p

    def para(self, text="", bold=False, indent=True, size=None, align=None):
        p = self.d.add_paragraph()
        if not indent:
            p.paragraph_format.first_line_indent = Cm(0)
        if align is not None:
            p.alignment = align
        if text:
            self._font(p.add_run(text), size, bold)
        return p

    def mono(self, lines, size=9.5):
        """Monospaced block for hex dumps and command lines."""
        if isinstance(lines, str):
            lines = [lines]
        for line in lines:
            p = self.d.add_paragraph()
            p.paragraph_format.first_line_indent = Cm(0)
            p.paragraph_format.left_indent = Cm(0.4)
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.line_spacing = 1.05
            self._font(p.add_run(line), size, mono=True)
        gap = self.d.add_paragraph()
        gap.paragraph_format.space_after = Pt(3)
        gap.paragraph_format.line_spacing = Pt(3)
        self._font(gap.add_run(""), 2)

    def table(self, heads, rows, widths=None, header=True, size=9.5):
        cols = len(heads)
        t = self.d.add_table(rows=1, cols=cols)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        if widths is None:
            widths = [16.0 / cols] * cols
        for i, w in enumerate(widths):
            t.columns[i].width = Cm(w)
        for i, txt in enumerate(heads):
            t.rows[0].cells[i].text = str(txt)
        if not header:
            t._tbl.remove(t.rows[0]._tr)
        for row in rows:
            cells = t.add_row().cells
            for i, txt in enumerate(row):
                cells[i].text = str(txt)
        b = OxmlElement("w:tblBorders")
        for edge in ["top", "left", "bottom", "right", "insideH", "insideV"]:
            el = OxmlElement("w:" + edge)
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), "4")
            el.set(qn("w:color"), "9DB2C6")
            b.append(el)
        t._tbl.tblPr.append(b)
        for ri, row in enumerate(t.rows):
            trpr = row._tr.get_or_add_trPr()
            trpr.append(OxmlElement("w:cantSplit"))
            if ri == 0 and header:
                trpr.append(OxmlElement("w:tblHeader"))
            for ci, cell in enumerate(row.cells):
                cell.width = Cm(widths[ci])
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tcpr = cell._tc.get_or_add_tcPr()
                mar = OxmlElement("w:tcMar")
                for edge in ["top", "bottom", "left", "right"]:
                    e = OxmlElement("w:" + edge)
                    e.set(qn("w:w"), "80")
                    e.set(qn("w:type"), "dxa")
                    mar.append(e)
                tcpr.append(mar)
                if ri == 0 and header:
                    shd = OxmlElement("w:shd")
                    shd.set(qn("w:fill"), "E8EEF4")
                    tcpr.append(shd)
                for pp in cell.paragraphs:
                    pp.paragraph_format.first_line_indent = Cm(0)
                    pp.paragraph_format.space_after = Pt(1)
                    pp.paragraph_format.line_spacing = 1.1
                    for rr in pp.runs:
                        self._font(rr, size, ri == 0 and header)
        gap = self.d.add_paragraph()
        gap.paragraph_format.space_after = Pt(3)
        gap.paragraph_format.line_spacing = Pt(3)
        self._font(gap.add_run(""), 2)
        return t

    def figure(self, path, caption, width=16.0):
        p = self.d.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.keep_with_next = True
        p.add_run().add_picture(str(path), width=Cm(width))
        cp = self.d.add_paragraph(caption, style="Caption")
        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        return cp

    def page_break(self):
        self.d.add_page_break()

    def save(self, path):
        self.d.core_properties.author = ""
        self.d.save(path)
        return path
