#!/usr/bin/env python
"""check_docx_fonts.py - which installed fonts actually cover every character
your DOCX uses?

A font missing a glyph makes the renderer substitute a *different* typeface for
just that character — the main cause of uneven-looking Chinese text. Run this
BEFORE rendering so you pick a family with full coverage.

Uses the Windows GDI (GetGlyphIndicesW); no third-party packages.

Usage:
  python check_docx_fonts.py report.docx [more.docx ...]
  python check_docx_fonts.py --dir "C:\\path\\to\\lab" [--latest]

Why --dir exists: PowerShell mangles non-ASCII characters when passing paths as
arguments to a native program (a CJK filename arrives corrupted). Resolving the
path inside Python avoids the shell entirely — always prefer --dir on a path
containing Chinese characters.
"""
import argparse
import ctypes
import glob
import os
import sys
from ctypes import wintypes

from docx import Document

gdi32 = ctypes.windll.gdi32
user32 = ctypes.windll.user32

GGI_MARK_NONEXISTING_GLYPHS = 0x0001
DEFAULT_CHARSET = 1
OUT_TT_PRECIS = 4
CLIP_DEFAULT_PRECIS = 0
ANTIALIASED_QUALITY = 4

gdi32.CreateFontW.restype = wintypes.HGDIOBJ
gdi32.CreateFontW.argtypes = [ctypes.c_int] * 5 + [wintypes.DWORD, wintypes.DWORD,
                                                   wintypes.DWORD, wintypes.DWORD,
                                                   wintypes.DWORD, wintypes.DWORD,
                                                   wintypes.DWORD, wintypes.DWORD,
                                                   wintypes.LPCWSTR]
gdi32.SelectObject.restype = wintypes.HGDIOBJ
gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.GetGlyphIndicesW.argtypes = [wintypes.HDC, wintypes.LPCWSTR, ctypes.c_int,
                                   ctypes.POINTER(wintypes.WORD), wintypes.DWORD]
user32.GetDC.restype = wintypes.HDC
user32.GetDC.argtypes = [wintypes.HWND]
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]

CANDIDATES = ["Microsoft YaHei", "DengXian", "SimSun", "SimHei", "KaiTi",
              "FangSong", "NSimSun", "Noto Sans SC", "Noto Serif SC"]


def chars_in_doc(path):
    d = Document(path)
    chars = set()
    for p in d.paragraphs:
        chars |= set(p.text)
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                chars |= set(c.text)
    for s in d.sections:
        for p in list(s.header.paragraphs) + list(s.footer.paragraphs):
            chars |= set(p.text)
    return {c for c in chars if ord(c) > 0x2000 or c.strip() == ""}


def coverage(font_name, chars):
    hdc = user32.GetDC(None)
    hfont = gdi32.CreateFontW(-20, 0, 0, 0, 400, 0, 0, 0, DEFAULT_CHARSET,
                              OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                              ANTIALIASED_QUALITY, 0, font_name)
    old = gdi32.SelectObject(hdc, hfont)
    missing = []
    try:
        for ch in sorted(chars):
            glyphs = (wintypes.WORD * 1)()
            n = gdi32.GetGlyphIndicesW(hdc, ch, 1, glyphs, GGI_MARK_NONEXISTING_GLYPHS)
            if n == 0 or glyphs[0] == 0xFFFF:
                missing.append(ch)
    finally:
        gdi32.SelectObject(hdc, old)
        gdi32.DeleteObject(hfont)
        user32.ReleaseDC(None, hdc)
    return missing


def resolve_targets(args):
    """Resolve which documents to check WITHOUT relying on shell-passed CJK."""
    targets = list(args.files)
    if args.dir:
        pattern = os.path.join(args.dir, "*.docx")
        found = [f for f in glob.glob(pattern) if not os.path.basename(f).startswith("~$")]
        if args.latest:
            found.sort(key=os.path.getmtime, reverse=True)
            found = found[:1]
        targets.extend(found)
    seen, out = set(), []
    for t in targets:
        ap = os.path.abspath(t)
        if ap not in seen:
            seen.add(ap)
            out.append(ap)
    return out


def main(argv):
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("files", nargs="*")
    ap.add_argument("--dir", help="directory to scan for *.docx (CJK-safe)")
    ap.add_argument("--latest", action="store_true",
                    help="with --dir, check only the most recently modified file")
    args = ap.parse_args(argv)

    paths = resolve_targets(args)
    if not paths:
        raise SystemExit("no documents to check (pass files or --dir)")

    rc = 0
    for path in paths:
        if not os.path.isfile(path):
            print(f"\n{path}\n   ERROR: not found")
            rc = 1
            continue
        chars = chars_in_doc(path)
        print(f"\n{path}")
        print(f"   distinct non-ASCII chars: {len(chars)}")
        full = []
        for name in CANDIDATES:
            miss = coverage(name, chars)
            mark = "OK  " if not miss else "MISS"
            print(f"   {mark} {name:18s} missing {len(miss):3d}  {''.join(miss[:40])}")
            if not miss:
                full.append(name)
        print(f"   fonts with FULL coverage: {', '.join(full) if full else 'none'}")
        if not full:
            rc = 1
            print("   WARNING: no candidate covers everything; the renderer WILL "
                  "substitute fonts. Add a fallback font or replace rare characters.")
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
